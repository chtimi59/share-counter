<html><body><h1>
Configuration-File<br>
*generation script*
</h1><hr>

<?PHP

	// -------- SHOULD BE CONFIGURED ACCORDING YOUR NEEDS ----------------
	
	$confPath = 'c:/dev/share-counter.conf';      // output file (file referred in "conf.php")
	$secretHash = '1289rtpf%7+9';                 // whatever you want (needed by "conf.php")
	$DATA = array(
		
			// SQL radius_config
			'sql_Host'   => 'localhost',          // SQL server host:port
			'sql_login'  => 'mySqlLogin',         // LOGIN
			'sql_pw'     => 'mySqlPassword',      // PASSWORD 
			'sql_isPW'   => true,                 // Need password ?
			
			// DATABASE
			'main_db'     => 'main', 			   // MAIN
			'counter_db'  => 'cloud',	 		   // COUNTERS RECORDS (should be the same as main_db)
			
			// MAIL CONFIG
			'smtp_Host'   => 'my.smtp.server',     // SMTP server
			'smtp_port'   => 465,                  // set the SMTP port	
			'smtp_login'  => 'mySmtpLogin',        // LOGIN
			'smtp_pw'     => 'mySmtpPassword',     // PW
			'smtp_auth'   => true,                 // enable SMTP authentication
			'smtp_secure' => 'ssl',                // sets the prefix to the server
			
			// ADMIN
			'admin_email'   => 'admin@yoursite.com',     // ADMIN EMAIL
			'noreply_email' => 'no-reply@yoursite.com', // NO-REPLAY EMAIL
			'admin'         => '6A561157-70A6-424C-8963-598E627966A3', // if you change it, update database entry accordignly			
	);
	
	// -------------------------------------------------------------------

	
	/* 1. Generate conf file */
	$string = json_encode($DATA);
	$encryptionMethod = 'aes128';
	$iv = mcrypt_create_iv(16, MCRYPT_DEV_RANDOM);
	print "Generate:<br>\n$confPath";
	print "\n<hr>\n";
	if (!file_put_contents ($confPath, $iv.openssl_encrypt ($string, $encryptionMethod, $secretHash, NULL, $iv))) {
		print "WRITE ERROR!";
		die();
	}
	
	/* 2. Read back for test */
	$encryptedMessage = file_get_contents ($confPath);	
	if (!$encryptedMessage) {
		print "READ ERROR!\n";
		die();
	}
	$iv = substr($encryptedMessage, 0, 16);
	$encryptedMessage = substr($encryptedMessage, 16);
	$readBack = openssl_decrypt($encryptedMessage, $encryptionMethod, $secretHash, 0, $iv);
	$DATA_BACK = json_decode($readBack, true);
	print "Configuration:<ul>\n";
	foreach ($DATA as $key => $value) {
		print "<li>$key: $value</li>\n";
		if($DATA[$key]!=$DATA_BACK[$key]) {
			print "Read back ERROR!<br>\n";
			die();
		}
	}
	print "</ul>\n";
	print "<hr>\n";
	print "SUCCESS!<br>\n";	
?>

</body></html>